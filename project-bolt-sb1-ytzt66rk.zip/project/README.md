# AI Song Recommendation System with Facial Emotion Detection

A Python-based AI system that uses computer vision and machine learning to detect emotions from facial expressions and recommend songs based on the detected mood.

## Features

- **Real-time Emotion Detection**: Uses OpenCV and TensorFlow to analyze facial expressions
- **Smart Song Recommendations**: Curated playlists based on detected emotions
- **Multiple Detection Methods**: Supports both Haar Cascades and HOG-based face detection
- **Music Playback**: Integrated music player using pygame
- **Emotion History**: Tracks emotion patterns over time
- **Custom Model Training**: Includes scripts to train your own emotion recognition model

## Requirements

```bash
pip install -r requirements.txt
```

### Required Libraries:
- OpenCV (opencv-python)
- TensorFlow
- face_recognition
- NumPy
- pygame (for music playback)
- scikit-learn
- matplotlib
- Pillow

## Installation

1. **Clone the repository**:
```bash
git clone <repository-url>
cd ai-song-recommender
```

2. **Install dependencies**:
```bash
pip install -r requirements.txt
```

3. **Download pre-trained model** (optional):
   - Place your trained emotion model as `models/emotion_model.h5`
   - Or train a new model using the provided training script

4. **Set up song database**:
   - The system includes a default song database
   - Add your own music files to the appropriate directories
   - Update the songs database JSON file with your music collection

## Usage

### Basic Usage

```bash
python emotion_detector.py
```

### Controls:
- **'q'**: Quit the application
- **'r'**: Show song recommendations for current emotion
- **'p'**: Play/pause music

### Training Your Own Model

1. **Download the FER2013 dataset**:
   - Get it from [Kaggle FER2013 Dataset](https://www.kaggle.com/datasets/msambare/fer2013)
   - Place `fer2013.csv` in the `data/` directory

2. **Train the model**:
```bash
python train_emotion_model.py
```

3. **The trained model will be saved as `models/emotion_model.h5`**

## System Architecture

### 1. Emotion Detection (`EmotionDetector`)
- Uses OpenCV for face detection
- Preprocesses facial images for emotion recognition
- Employs CNN model for emotion classification
- Supports 7 emotions: angry, disgust, fear, happy, neutral, sad, surprise

### 2. Song Recommendation (`SongRecommender`)
- Maps emotions to curated song playlists
- Considers energy levels and musical attributes
- Generates personalized recommendations based on emotion history

### 3. Music Player (`MusicPlayer`)
- Simple pygame-based music playback
- Supports play, pause, stop functionality
- Integrates with recommendation system

### 4. Main Application (`AIsongRecommendationApp`)
- Orchestrates all components
- Handles real-time video processing
- Manages user interactions and display

## Emotion-to-Music Mapping

The system maps detected emotions to specific musical characteristics:

- **Happy**: High energy, positive valence (Pop, Funk, Upbeat songs)
- **Sad**: Low energy, negative valence (Ballads, Slow songs)
- **Angry**: High energy, negative valence (Metal, Rock, Aggressive songs)
- **Surprised**: Medium-high energy, positive valence (Upbeat Pop, Dance)
- **Neutral**: Medium energy, neutral valence (Ambient, Classical)
- **Fear**: Low-medium energy, negative valence (Atmospheric, Emotional)
- **Disgust**: Variable energy, negative valence (Alternative, Edgy Pop)

## Model Architecture

The emotion recognition model uses a Convolutional Neural Network (CNN):

```
Input (48x48 grayscale image)
↓
Conv2D(32) → BatchNorm → Conv2D(32) → MaxPool → Dropout
↓
Conv2D(64) → BatchNorm → Conv2D(64) → MaxPool → Dropout
↓
Conv2D(128) → BatchNorm → Conv2D(128) → MaxPool → Dropout
↓
Conv2D(256) → BatchNorm → MaxPool → Dropout
↓
Flatten → Dense(512) → BatchNorm → Dropout → Dense(256) → Dropout
↓
Dense(7) → Softmax (7 emotion classes)
```

## Customization

### Adding New Songs
Edit `data/songs_database.json` to add new songs:

```json
{
  "happy": [
    {
      "title": "Your Song Title",
      "artist": "Artist Name",
      "duration": "3:45",
      "genre": "Pop",
      "energy": 0.8,
      "valence": 0.9,
      "danceability": 0.7
    }
  ]
}
```

### Adjusting Emotion Detection
- Modify `emotion_detection_interval` in the main loop
- Adjust confidence thresholds
- Fine-tune preprocessing parameters

### Custom Model Training
- Use your own dataset
- Modify the CNN architecture in `train_emotion_model.py`
- Experiment with different hyperparameters

## Performance Tips

1. **Camera Quality**: Use good lighting for better face detection
2. **Model Accuracy**: Train on diverse datasets for better emotion recognition
3. **Processing Speed**: Adjust detection interval based on your hardware
4. **Memory Usage**: Monitor memory usage with large song databases

## Troubleshooting

### Common Issues:

1. **Camera not detected**:
   - Check camera permissions
   - Try different camera indices (0, 1, 2...)

2. **Model loading errors**:
   - Ensure TensorFlow version compatibility
   - Check model file path and permissions

3. **Face detection issues**:
   - Improve lighting conditions
   - Ensure face is clearly visible
   - Try different detection methods

4. **Music playback problems**:
   - Install pygame properly
   - Check audio file formats
   - Verify system audio settings

## Future Enhancements

- Integration with Spotify/Apple Music APIs
- Real-time audio analysis for mood detection
- Multi-face emotion detection
- Voice emotion recognition
- Mobile app development
- Cloud-based model serving

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- FER2013 dataset for emotion recognition training
- OpenCV community for computer vision tools
- TensorFlow team for machine learning framework
- Music artists and labels for the song database