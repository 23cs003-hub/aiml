"""
AI Song Recommendation System with Facial Emotion Detection
Requires: OpenCV, TensorFlow, face_recognition, numpy

Installation:
pip install -r requirements.txt
"""

import cv2
import numpy as np
import tensorflow as tf
from tensorflow import keras
import face_recognition
from typing import List, Dict, Tuple, Optional
import json
import os

class EmotionDetector:
    """Real-time emotion detection using OpenCV and TensorFlow"""
    
    def __init__(self, model_path: Optional[str] = None):
        self.emotions = ['angry', 'disgust', 'fear', 'happy', 'neutral', 'sad', 'surprise']
        self.model = None
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.model_path = model_path or 'models/emotion_model.h5'
        
    def load_model(self):
        """Load pre-trained emotion recognition model"""
        try:
            if os.path.exists(self.model_path):
                self.model = keras.models.load_model(self.model_path)
                print("Loaded existing emotion model")
            else:
                print("No pre-trained model found. Creating new model...")
                self.model = self._create_emotion_model()
                print("Created new emotion model")
            return True
        except Exception as e:
            print(f"Error loading model: {e}")
            return False
    
    def _create_emotion_model(self):
        """Create a CNN model for emotion recognition"""
        model = keras.Sequential([
            keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(48, 48, 1)),
            keras.layers.BatchNormalization(),
            keras.layers.Conv2D(64, (3, 3), activation='relu'),
            keras.layers.MaxPooling2D(2, 2),
            keras.layers.Dropout(0.25),
            
            keras.layers.Conv2D(128, (3, 3), activation='relu'),
            keras.layers.BatchNormalization(),
            keras.layers.Conv2D(128, (3, 3), activation='relu'),
            keras.layers.MaxPooling2D(2, 2),
            keras.layers.Dropout(0.25),
            
            keras.layers.Conv2D(256, (3, 3), activation='relu'),
            keras.layers.BatchNormalization(),
            keras.layers.MaxPooling2D(2, 2),
            keras.layers.Dropout(0.25),
            
            keras.layers.Flatten(),
            keras.layers.Dense(512, activation='relu'),
            keras.layers.BatchNormalization(),
            keras.layers.Dropout(0.5),
            keras.layers.Dense(len(self.emotions), activation='softmax')
        ])
        
        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def detect_faces(self, frame):
        """Detect faces in the frame using OpenCV"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray, 
            scaleFactor=1.1, 
            minNeighbors=5, 
            minSize=(30, 30)
        )
        return faces
    
    def detect_faces_hog(self, frame):
        """Alternative face detection using face_recognition library (HOG)"""
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        face_locations = face_recognition.face_locations(rgb_frame, model="hog")
        return face_locations
    
    def preprocess_face(self, face_img):
        """Preprocess face image for emotion recognition"""
        # Resize to 48x48 (standard for emotion recognition models)
        face_img = cv2.resize(face_img, (48, 48))
        
        # Convert to grayscale if needed
        if len(face_img.shape) == 3:
            face_img = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
        
        # Normalize pixel values
        face_img = face_img.astype('float32') / 255.0
        
        # Reshape for model input
        face_img = np.expand_dims(face_img, axis=0)
        face_img = np.expand_dims(face_img, axis=-1)
        
        return face_img
    
    def predict_emotion(self, face_img) -> Tuple[str, float]:
        """Predict emotion from face image"""
        if self.model is None:
            raise ValueError("Model not loaded. Call load_model() first.")
        
        processed_face = self.preprocess_face(face_img)
        predictions = self.model.predict(processed_face, verbose=0)
        
        emotion_idx = np.argmax(predictions[0])
        confidence = float(predictions[0][emotion_idx])
        emotion = self.emotions[emotion_idx]
        
        return emotion, confidence
    
    def detect_emotion_from_frame(self, frame) -> List[Dict]:
        """Detect emotions from all faces in frame"""
        faces = self.detect_faces(frame)
        results = []
        
        for (x, y, w, h) in faces:
            # Extract face region
            face_img = frame[y:y+h, x:x+w]
            
            try:
                emotion, confidence = self.predict_emotion(face_img)
                results.append({
                    'bbox': (x, y, w, h),
                    'emotion': emotion,
                    'confidence': confidence
                })
            except Exception as e:
                print(f"Error predicting emotion: {e}")
                continue
        
        return results

class SongRecommender:
    """Song recommendation system based on detected emotions"""
    
    def __init__(self, songs_db_path: str = 'data/songs_database.json'):
        self.songs_db_path = songs_db_path
        self.songs_database = self._load_songs_database()
        
    def _load_songs_database(self) -> Dict:
        """Load songs database from JSON file"""
        try:
            with open(self.songs_db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return self._create_default_database()
    
    def _create_default_database(self) -> Dict:
        """Create default songs database"""
        database = {
            'happy': [
                {'title': 'Happy', 'artist': 'Pharrell Williams', 'duration': '3:53', 'genre': 'Pop', 'energy': 0.9},
                {'title': 'Good as Hell', 'artist': 'Lizzo', 'duration': '3:38', 'genre': 'Pop', 'energy': 0.85},
                {'title': 'Can\'t Stop the Feeling!', 'artist': 'Justin Timberlake', 'duration': '3:56', 'genre': 'Pop', 'energy': 0.88},
                {'title': 'Walking on Sunshine', 'artist': 'Katrina and the Waves', 'duration': '3:58', 'genre': 'Rock', 'energy': 0.92}
            ],
            'sad': [
                {'title': 'Someone Like You', 'artist': 'Adele', 'duration': '4:45', 'genre': 'Pop', 'energy': 0.3},
                {'title': 'Mad World', 'artist': 'Gary Jules', 'duration': '3:07', 'genre': 'Alternative', 'energy': 0.2},
                {'title': 'Hurt', 'artist': 'Johnny Cash', 'duration': '3:38', 'genre': 'Country', 'energy': 0.25},
                {'title': 'Black', 'artist': 'Pearl Jam', 'duration': '5:43', 'genre': 'Grunge', 'energy': 0.4}
            ],
            'angry': [
                {'title': 'Break Stuff', 'artist': 'Limp Bizkit', 'duration': '2:47', 'genre': 'Nu Metal', 'energy': 0.95},
                {'title': 'Bodies', 'artist': 'Drowning Pool', 'duration': '3:23', 'genre': 'Metal', 'energy': 0.98},
                {'title': 'Killing in the Name', 'artist': 'Rage Against the Machine', 'duration': '5:14', 'genre': 'Rap Metal', 'energy': 0.96}
            ],
            'surprise': [
                {'title': 'Uptown Funk', 'artist': 'Mark Ronson ft. Bruno Mars', 'duration': '4:30', 'genre': 'Funk', 'energy': 0.87},
                {'title': 'I Gotta Feeling', 'artist': 'The Black Eyed Peas', 'duration': '4:05', 'genre': 'Pop', 'energy': 0.89}
            ],
            'neutral': [
                {'title': 'Weightless', 'artist': 'Marconi Union', 'duration': '8:10', 'genre': 'Ambient', 'energy': 0.1},
                {'title': 'Clair de Lune', 'artist': 'Claude Debussy', 'duration': '5:02', 'genre': 'Classical', 'energy': 0.15}
            ],
            'fear': [
                {'title': 'Breathe Me', 'artist': 'Sia', 'duration': '4:31', 'genre': 'Pop', 'energy': 0.4},
                {'title': 'Heavy', 'artist': 'Linkin Park ft. Kiiara', 'duration': '2:49', 'genre': 'Alternative', 'energy': 0.5}
            ],
            'disgust': [
                {'title': 'Toxic', 'artist': 'Britney Spears', 'duration': '3:19', 'genre': 'Pop', 'energy': 0.7},
                {'title': 'Bad Guy', 'artist': 'Billie Eilish', 'duration': '3:14', 'genre': 'Pop', 'energy': 0.6}
            ]
        }
        
        # Save default database
        os.makedirs(os.path.dirname(self.songs_db_path), exist_ok=True)
        with open(self.songs_db_path, 'w', encoding='utf-8') as f:
            json.dump(database, f, indent=2, ensure_ascii=False)
        
        return database
    
    def get_recommendations(self, emotion: str, num_songs: int = 5) -> List[Dict]:
        """Get song recommendations based on emotion"""
        emotion_songs = self.songs_database.get(emotion, [])
        
        if not emotion_songs:
            # Fallback to neutral if emotion not found
            emotion_songs = self.songs_database.get('neutral', [])
        
        # Sort by energy level and return top recommendations
        sorted_songs = sorted(emotion_songs, key=lambda x: x.get('energy', 0.5), reverse=True)
        return sorted_songs[:num_songs]
    
    def get_mood_playlist(self, emotions_history: List[str]) -> List[Dict]:
        """Create a playlist based on emotion history"""
        playlist = []
        
        # Get most common emotion
        emotion_counts = {}
        for emotion in emotions_history:
            emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
        
        dominant_emotion = max(emotion_counts, key=emotion_counts.get)
        
        # Get recommendations for dominant emotion
        recommendations = self.get_recommendations(dominant_emotion, 10)
        playlist.extend(recommendations)
        
        return playlist

class MusicPlayer:
    """Simple music player using pygame"""
    
    def __init__(self):
        try:
            import pygame
            pygame.mixer.init()
            self.pygame = pygame
            self.is_playing = False
            self.current_song = None
        except ImportError:
            print("pygame not available. Music playback disabled.")
            self.pygame = None
    
    def play_song(self, song_path: str):
        """Play a song file"""
        if not self.pygame:
            print(f"Would play: {song_path}")
            return
        
        try:
            self.pygame.mixer.music.load(song_path)
            self.pygame.mixer.music.play()
            self.is_playing = True
            self.current_song = song_path
        except Exception as e:
            print(f"Error playing song: {e}")
    
    def stop(self):
        """Stop current song"""
        if self.pygame and self.is_playing:
            self.pygame.mixer.music.stop()
            self.is_playing = False
    
    def pause(self):
        """Pause current song"""
        if self.pygame and self.is_playing:
            self.pygame.mixer.music.pause()
    
    def resume(self):
        """Resume paused song"""
        if self.pygame:
            self.pygame.mixer.music.unpause()

class AIsongRecommendationApp:
    """Main application class"""
    
    def __init__(self):
        self.emotion_detector = EmotionDetector()
        self.song_recommender = SongRecommender()
        self.music_player = MusicPlayer()
        self.cap = None
        self.emotions_history = []
        
    def initialize(self):
        """Initialize the application"""
        print("Initializing AI Song Recommendation System...")
        
        # Load emotion detection model
        if not self.emotion_detector.load_model():
            print("Failed to load emotion detection model")
            return False
        
        # Initialize camera
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            print("Error: Could not open camera")
            return False
        
        print("System initialized successfully!")
        return True
    
    def run(self):
        """Run the main application loop"""
        if not self.initialize():
            return
        
        print("Starting emotion detection and song recommendation...")
        print("Press 'q' to quit, 'r' for recommendations, 'p' to play/pause")
        
        frame_count = 0
        emotion_detection_interval = 30  # Detect emotion every 30 frames
        
        while True:
            ret, frame = self.cap.read()
            if not ret:
                print("Error reading from camera")
                break
            
            # Flip frame horizontally for mirror effect
            frame = cv2.flip(frame, 1)
            
            # Detect emotions periodically
            if frame_count % emotion_detection_interval == 0:
                emotions = self.emotion_detector.detect_emotion_from_frame(frame)
                
                if emotions:
                    dominant_emotion = max(emotions, key=lambda x: x['confidence'])
                    self.emotions_history.append(dominant_emotion['emotion'])
                    
                    # Keep only last 10 emotions
                    if len(self.emotions_history) > 10:
                        self.emotions_history.pop(0)
                    
                    print(f"Detected emotion: {dominant_emotion['emotion']} "
                          f"(confidence: {dominant_emotion['confidence']:.2f})")
            
            # Draw bounding boxes and emotions on frame
            emotions = self.emotion_detector.detect_emotion_from_frame(frame)
            for emotion_data in emotions:
                x, y, w, h = emotion_data['bbox']
                emotion = emotion_data['emotion']
                confidence = emotion_data['confidence']
                
                # Draw bounding box
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                
                # Draw emotion label
                label = f"{emotion}: {confidence:.2f}"
                cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 
                           0.9, (0, 255, 0), 2)
            
            # Display frame
            cv2.imshow('AI Song Recommender - Emotion Detection', frame)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('r'):
                self.show_recommendations()
            elif key == ord('p'):
                self.toggle_music()
            
            frame_count += 1
        
        self.cleanup()
    
    def show_recommendations(self):
        """Show song recommendations based on current emotions"""
        if not self.emotions_history:
            print("No emotions detected yet. Look at the camera!")
            return
        
        # Get most recent emotion
        current_emotion = self.emotions_history[-1]
        recommendations = self.song_recommender.get_recommendations(current_emotion)
        
        print(f"\n🎵 Song Recommendations for '{current_emotion}' mood:")
        print("-" * 50)
        
        for i, song in enumerate(recommendations, 1):
            print(f"{i}. {song['title']} - {song['artist']}")
            print(f"   Genre: {song['genre']} | Duration: {song['duration']}")
            print(f"   Energy Level: {song['energy']:.1f}/1.0")
            print()
    
    def toggle_music(self):
        """Toggle music playback"""
        if self.music_player.is_playing:
            self.music_player.pause()
            print("Music paused")
        else:
            # For demo purposes, just print what would be played
            if self.emotions_history:
                current_emotion = self.emotions_history[-1]
                recommendations = self.song_recommender.get_recommendations(current_emotion, 1)
                if recommendations:
                    song = recommendations[0]
                    print(f"🎵 Now playing: {song['title']} - {song['artist']}")
    
    def cleanup(self):
        """Clean up resources"""
        if self.cap:
            self.cap.release()
        cv2.destroyAllWindows()
        self.music_player.stop()
        print("Application closed successfully!")

if __name__ == "__main__":
    app = AIsongRecommendationApp()
    app.run()