# Setup Instructions for AI Song Recommender

## Prerequisites

Before running this AI Song Recommendation system, you need to install the required dependencies. This system uses advanced computer vision and machine learning libraries that are not available in the WebContainer environment.

## Installation Steps

### 1. Set up Python Environment

```bash
# Create virtual environment (recommended)
python -m venv ai_song_env

# Activate virtual environment
# On Windows:
ai_song_env\Scripts\activate
# On macOS/Linux:
source ai_song_env/bin/activate
```

### 2. Install Required Packages

```bash
# Install all dependencies
pip install -r requirements.txt

# Or install individually:
pip install opencv-python==4.8.1.78
pip install tensorflow==2.13.0
pip install face-recognition==1.3.0
pip install numpy==1.24.3
pip install pygame==2.5.2
pip install scikit-learn==1.3.0
pip install matplotlib==3.7.2
pip install pillow==10.0.0
```

### 3. Additional System Dependencies

#### For face_recognition library:

**On Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install build-essential cmake
sudo apt-get install libopenblas-dev liblapack-dev
sudo apt-get install libx11-dev libgtk-3-dev
```

**On macOS:**
```bash
brew install cmake
```

**On Windows:**
- Install Visual Studio Build Tools
- Or use conda: `conda install -c conda-forge dlib`

### 4. Download Dataset (for training)

If you want to train your own emotion recognition model:

1. Go to [Kaggle FER2013 Dataset](https://www.kaggle.com/datasets/msambare/fer2013)
2. Download the `fer2013.csv` file
3. Create a `data/` directory in your project
4. Place the CSV file in `data/fer2013.csv`

### 5. Create Directory Structure

```bash
mkdir -p models
mkdir -p data
mkdir -p music
```

### 6. Test Installation

```python
# Test script to verify installation
import cv2
import tensorflow as tf
import face_recognition
import numpy as np
import pygame

print("OpenCV version:", cv2.__version__)
print("TensorFlow version:", tf.__version__)
print("NumPy version:", np.__version__)
print("All libraries imported successfully!")

# Test camera access
cap = cv2.VideoCapture(0)
if cap.isOpened():
    print("Camera access: OK")
    cap.release()
else:
    print("Camera access: FAILED")
```

## Running the Application

### Option 1: Run Main Application
```bash
python emotion_detector.py
```

### Option 2: Train Your Own Model First
```bash
# Train emotion recognition model (requires FER2013 dataset)
python train_emotion_model.py

# Then run the main application
python emotion_detector.py
```

## Configuration

### Camera Settings
- The system uses camera index 0 by default
- If you have multiple cameras, modify the camera index in the code
- Ensure good lighting for better face detection

### Model Settings
- Pre-trained models should be placed in `models/` directory
- The system will create a basic model if none is found
- For better accuracy, train on the FER2013 dataset

### Music Database
- Edit `data/songs_database.json` to add your music collection
- Add actual music files to the `music/` directory
- Update file paths in the song database

## Troubleshooting

### Common Installation Issues:

1. **dlib installation fails:**
   ```bash
   # Try using conda instead of pip
   conda install -c conda-forge dlib
   ```

2. **OpenCV camera issues:**
   ```bash
   # Install additional codecs
   pip install opencv-contrib-python
   ```

3. **TensorFlow GPU support:**
   ```bash
   # For GPU acceleration (optional)
   pip install tensorflow-gpu==2.13.0
   ```

4. **pygame audio issues:**
   ```bash
   # On Linux, install additional audio libraries
   sudo apt-get install python3-pygame
   ```

### Performance Optimization:

1. **For better performance:**
   - Use GPU acceleration with TensorFlow-GPU
   - Reduce camera resolution if needed
   - Adjust emotion detection interval

2. **For lower-end hardware:**
   - Use smaller model architectures
   - Reduce batch sizes during training
   - Lower camera FPS

## Hardware Requirements

### Minimum Requirements:
- CPU: Intel i3 or equivalent
- RAM: 4GB
- Storage: 2GB free space
- Camera: Any USB webcam

### Recommended Requirements:
- CPU: Intel i5 or equivalent
- RAM: 8GB
- GPU: NVIDIA GTX 1050 or better (for training)
- Storage: 5GB free space
- Camera: HD webcam with good low-light performance

## Next Steps

1. **Test the basic functionality** with the default model
2. **Train your own model** using the FER2013 dataset for better accuracy
3. **Customize the song database** with your preferred music
4. **Experiment with different settings** to optimize for your use case

## Support

If you encounter issues:
1. Check the troubleshooting section above
2. Verify all dependencies are correctly installed
3. Test individual components (camera, model loading, etc.)
4. Check system compatibility and hardware requirements

The system is designed to work on Windows, macOS, and Linux with Python 3.7+.