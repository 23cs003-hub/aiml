import React, { useState, useEffect } from 'react';
import { Camera, CameraOff, Loader } from 'lucide-react';
import { Header } from './components/Header';
import { CameraView } from './components/CameraView';
import { EmotionDisplay } from './components/EmotionDisplay';
import { SongRecommendations } from './components/SongRecommendations';
import { getRecommendationsForEmotion } from './data/songs';
import { emotionDetector } from './utils/emotionDetection';

function App() {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [currentEmotion, setCurrentEmotion] = useState('neutral');
  const [confidence, setConfidence] = useState(85);
  const [isLoading, setIsLoading] = useState(true);
  const [recommendations, setRecommendations] = useState(getRecommendationsForEmotion('neutral'));

  useEffect(() => {
    const initializeApp = async () => {
      setIsLoading(true);
      await emotionDetector.loadModel();
      setIsLoading(false);
    };

    initializeApp();
  }, []);

  useEffect(() => {
    setRecommendations(getRecommendationsForEmotion(currentEmotion));
  }, [currentEmotion]);

  const handleEmotionDetected = (emotion: string) => {
    setCurrentEmotion(emotion);
    setConfidence(Math.floor(Math.random() * 30) + 70); // Simulate confidence between 70-100%
  };

  const toggleCamera = () => {
    setIsCameraActive(!isCameraActive);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-indigo-50 flex items-center justify-center">
        <div className="text-center">
          <Loader className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Loading AI Models...</h2>
          <p className="text-gray-500">Preparing emotion detection system</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-indigo-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        <Header />

        <div className="grid lg:grid-cols-3 gap-8 mb-8">
          {/* Camera Control */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-800">Emotion Detection</h2>
                <button
                  onClick={toggleCamera}
                  className={`flex items-center px-4 py-2 rounded-lg font-medium transition-colors ${
                    isCameraActive
                      ? 'bg-red-500 hover:bg-red-600 text-white'
                      : 'bg-blue-500 hover:bg-blue-600 text-white'
                  }`}
                >
                  {isCameraActive ? (
                    <>
                      <CameraOff className="w-4 h-4 mr-2" />
                      Stop Camera
                    </>
                  ) : (
                    <>
                      <Camera className="w-4 h-4 mr-2" />
                      Start Camera
                    </>
                  )}
                </button>
              </div>

              <CameraView 
                isActive={isCameraActive}
                onEmotionDetected={handleEmotionDetected}
              />
            </div>
          </div>

          {/* Emotion Display */}
          <div>
            <EmotionDisplay emotion={currentEmotion} confidence={confidence} />
          </div>
        </div>

        {/* Song Recommendations */}
        <SongRecommendations 
          songs={recommendations}
          emotion={currentEmotion}
        />

        {/* Instructions */}
        <div className="mt-8 bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-semibold mb-3 text-gray-800">How it works:</h3>
          <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-600">
            <div className="flex items-start">
              <div className="bg-purple-100 text-purple-600 rounded-full p-1 mr-3 mt-1">1</div>
              <div>
                <strong>Enable Camera:</strong> Allow access to your webcam for real-time emotion detection
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-purple-100 text-purple-600 rounded-full p-1 mr-3 mt-1">2</div>
              <div>
                <strong>AI Analysis:</strong> Our AI analyzes your facial expressions to detect emotions
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-purple-100 text-purple-600 rounded-full p-1 mr-3 mt-1">3</div>
              <div>
                <strong>Get Recommendations:</strong> Receive personalized song suggestions based on your mood
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;