import React, { useRef, useEffect, useState } from 'react';
import { Camera, CameraOff } from 'lucide-react';

interface CameraViewProps {
  onEmotionDetected: (emotion: string) => void;
  isActive: boolean;
}

export const CameraView: React.FC<CameraViewProps> = ({ onEmotionDetected, isActive }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [error, setError] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (isActive) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => stopCamera();
  }, [isActive]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
        audio: false
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setHasPermission(true);
        setError('');
        
        // Start emotion detection simulation
        startEmotionDetection();
      }
    } catch (err) {
      setHasPermission(false);
      setError('Camera access denied or not available');
      console.error('Camera error:', err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  const startEmotionDetection = () => {
    const interval = setInterval(() => {
      if (!isActive || !videoRef.current) {
        clearInterval(interval);
        return;
      }

      setIsProcessing(true);
      
      // Simulate emotion detection processing time
      setTimeout(() => {
        const emotions = ['happy', 'sad', 'angry', 'surprised', 'neutral'];
        const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
        onEmotionDetected(randomEmotion);
        setIsProcessing(false);
      }, 500);
    }, 3000); // Detect emotion every 3 seconds
  };

  if (hasPermission === false) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-8 text-center">
        <CameraOff className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-red-800 mb-2">Camera Access Required</h3>
        <p className="text-red-600 mb-4">{error}</p>
        <button
          onClick={startCamera}
          className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="bg-gray-900 rounded-lg overflow-hidden shadow-lg">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-64 object-cover"
        />
        <canvas
          ref={canvasRef}
          className="absolute top-0 left-0 w-full h-full opacity-0"
        />
      </div>
      
      {isProcessing && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
          <div className="bg-white rounded-full p-3">
            <Camera className="w-6 h-6 text-blue-500 animate-pulse" />
          </div>
        </div>
      )}

      <div className="absolute bottom-4 left-4 bg-black bg-opacity-70 text-white px-3 py-1 rounded-full text-sm">
        {isActive ? 'Analyzing...' : 'Camera Off'}
      </div>
    </div>
  );
};