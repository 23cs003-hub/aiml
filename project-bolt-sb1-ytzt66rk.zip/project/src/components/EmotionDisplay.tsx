import React from 'react';
import { Smile, Frown, Angry, Zap, Minus } from 'lucide-react';

interface EmotionDisplayProps {
  emotion: string;
  confidence: number;
}

const emotionIcons = {
  happy: { icon: Smile, color: 'text-yellow-500', bg: 'bg-yellow-100' },
  sad: { icon: Frown, color: 'text-blue-500', bg: 'bg-blue-100' },
  angry: { icon: Angry, color: 'text-red-500', bg: 'bg-red-100' },
  surprised: { icon: Zap, color: 'text-orange-500', bg: 'bg-orange-100' },
  neutral: { icon: Minus, color: 'text-gray-500', bg: 'bg-gray-100' }
};

export const EmotionDisplay: React.FC<EmotionDisplayProps> = ({ emotion, confidence }) => {
  const emotionData = emotionIcons[emotion as keyof typeof emotionIcons] || emotionIcons.neutral;
  const Icon = emotionData.icon;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 text-center">
      <div className={`w-16 h-16 rounded-full ${emotionData.bg} flex items-center justify-center mx-auto mb-4`}>
        <Icon className={`w-8 h-8 ${emotionData.color}`} />
      </div>
      
      <h3 className="text-xl font-semibold capitalize mb-2">{emotion}</h3>
      
      <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
        <div 
          className={`h-2 rounded-full transition-all duration-1000 ${emotionData.color.replace('text-', 'bg-')}`}
          style={{ width: `${confidence}%` }}
        />
      </div>
      
      <p className="text-sm text-gray-600">{confidence.toFixed(1)}% confidence</p>
    </div>
  );
};