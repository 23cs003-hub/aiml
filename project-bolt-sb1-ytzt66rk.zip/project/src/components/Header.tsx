import React from 'react';
import { Brain, Music } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="text-center mb-8">
      <div className="flex items-center justify-center mb-4">
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-3 rounded-full mr-3">
          <Brain className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          AI Song Recommender
        </h1>
        <div className="bg-gradient-to-r from-pink-500 to-purple-500 p-3 rounded-full ml-3">
          <Music className="w-8 h-8 text-white" />
        </div>
      </div>
      
      <p className="text-gray-600 max-w-2xl mx-auto text-lg">
        Let AI analyze your facial expressions and discover the perfect music for your mood. 
        Just turn on your camera and let the magic happen!
      </p>
    </header>
  );
};