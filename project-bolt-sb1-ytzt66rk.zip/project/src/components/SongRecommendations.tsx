import React from 'react';
import { Play, Music, Heart } from 'lucide-react';
import { Song } from '../types/emotion';

interface SongRecommendationsProps {
  songs: Song[];
  emotion: string;
}

export const SongRecommendations: React.FC<SongRecommendationsProps> = ({ songs, emotion }) => {
  const emotionColors = {
    happy: 'from-yellow-400 to-orange-500',
    sad: 'from-blue-400 to-indigo-500',
    angry: 'from-red-400 to-pink-500',
    surprised: 'from-orange-400 to-yellow-500',
    neutral: 'from-gray-400 to-gray-500'
  };

  const gradientClass = emotionColors[emotion as keyof typeof emotionColors] || emotionColors.neutral;

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className={`bg-gradient-to-r ${gradientClass} px-6 py-4`}>
        <div className="flex items-center text-white">
          <Music className="w-6 h-6 mr-2" />
          <h3 className="text-xl font-semibold capitalize">
            {emotion === 'neutral' ? 'Calm' : emotion} Vibes
          </h3>
        </div>
      </div>

      <div className="p-6">
        {songs.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            <Music className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No recommendations available for this emotion</p>
          </div>
        ) : (
          <div className="space-y-4">
            {songs.map((song) => (
              <div
                key={song.id}
                className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors group"
              >
                <button className="w-10 h-10 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center text-white transition-colors mr-4 group-hover:scale-105">
                  <Play className="w-4 h-4 ml-0.5" />
                </button>
                
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900">{song.title}</h4>
                  <p className="text-gray-600 text-sm">{song.artist}</p>
                </div>
                
                <div className="text-right">
                  <p className="text-gray-500 text-sm">{song.duration}</p>
                  <button className="text-gray-400 hover:text-red-500 transition-colors mt-1">
                    <Heart className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};