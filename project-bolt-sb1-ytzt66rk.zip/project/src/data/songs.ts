import { Song } from '../types/emotion';

export const songDatabase: Song[] = [
  // Happy songs
  {
    id: '1',
    title: 'Happy',
    artist: 'Pharrell Williams',
    duration: '3:53',
    emotion: 'happy'
  },
  {
    id: '2',
    title: 'Good as Hell',
    artist: 'Lizzo',
    duration: '3:38',
    emotion: 'happy'
  },
  {
    id: '3',
    title: 'Can\'t Stop the Feeling!',
    artist: 'Justin Timberlake',
    duration: '3:56',
    emotion: 'happy'
  },
  {
    id: '4',
    title: 'Walking on Sunshine',
    artist: 'Katrina and the Waves',
    duration: '3:58',
    emotion: 'happy'
  },
  
  // Sad songs
  {
    id: '5',
    title: 'Someone Like You',
    artist: 'Adele',
    duration: '4:45',
    emotion: 'sad'
  },
  {
    id: '6',
    title: 'Mad World',
    artist: 'Gary Jules',
    duration: '3:07',
    emotion: 'sad'
  },
  {
    id: '7',
    title: 'Hurt',
    artist: 'Johnny Cash',
    duration: '3:38',
    emotion: 'sad'
  },
  {
    id: '8',
    title: 'Black',
    artist: 'Pearl Jam',
    duration: '5:43',
    emotion: 'sad'
  },
  
  // Angry songs
  {
    id: '9',
    title: 'Break Stuff',
    artist: 'Limp Bizkit',
    duration: '2:47',
    emotion: 'angry'
  },
  {
    id: '10',
    title: 'Bodies',
    artist: 'Drowning Pool',
    duration: '3:23',
    emotion: 'angry'
  },
  {
    id: '11',
    title: 'Killing in the Name',
    artist: 'Rage Against the Machine',
    duration: '5:14',
    emotion: 'angry'
  },
  
  // Surprised/Excited songs
  {
    id: '12',
    title: 'Uptown Funk',
    artist: 'Mark Ronson ft. Bruno Mars',
    duration: '4:30',
    emotion: 'surprised'
  },
  {
    id: '13',
    title: 'I Gotta Feeling',
    artist: 'The Black Eyed Peas',
    duration: '4:05',
    emotion: 'surprised'
  },
  
  // Neutral/Calm songs
  {
    id: '14',
    title: 'Weightless',
    artist: 'Marconi Union',
    duration: '8:10',
    emotion: 'neutral'
  },
  {
    id: '15',
    title: 'Clair de Lune',
    artist: 'Claude Debussy',
    duration: '5:02',
    emotion: 'neutral'
  },
  {
    id: '16',
    title: 'Spiegel im Spiegel',
    artist: 'Arvo Pärt',
    duration: '6:00',
    emotion: 'neutral'
  }
];

export const getRecommendationsForEmotion = (emotion: string): Song[] => {
  return songDatabase.filter(song => song.emotion === emotion.toLowerCase());
};