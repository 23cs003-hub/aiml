export interface Emotion {
  name: string;
  confidence: number;
  color: string;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  duration: string;
  emotion: string;
  preview?: string;
}

export interface EmotionDetectionResult {
  emotion: Emotion;
  confidence: number;
}