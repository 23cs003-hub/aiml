"""
Script to train emotion recognition model using TensorFlow
This would be used to create the emotion_model.h5 file
"""

import tensorflow as tf
from tensorflow import keras
import numpy as np
import cv2
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt

class EmotionModelTrainer:
    """Train emotion recognition model from scratch"""
    
    def __init__(self):
        self.emotions = ['angry', 'disgust', 'fear', 'happy', 'neutral', 'sad', 'surprise']
        self.img_size = 48
        self.model = None
        
    def create_model(self):
        """Create CNN model architecture for emotion recognition"""
        model = keras.Sequential([
            # First Convolutional Block
            keras.layers.Conv2D(32, (3, 3), activation='relu', 
                              input_shape=(self.img_size, self.img_size, 1)),
            keras.layers.BatchNormalization(),
            keras.layers.Conv2D(32, (3, 3), activation='relu'),
            keras.layers.MaxPooling2D(2, 2),
            keras.layers.Dropout(0.25),
            
            # Second Convolutional Block
            keras.layers.Conv2D(64, (3, 3), activation='relu'),
            keras.layers.BatchNormalization(),
            keras.layers.Conv2D(64, (3, 3), activation='relu'),
            keras.layers.MaxPooling2D(2, 2),
            keras.layers.Dropout(0.25),
            
            # Third Convolutional Block
            keras.layers.Conv2D(128, (3, 3), activation='relu'),
            keras.layers.BatchNormalization(),
            keras.layers.Conv2D(128, (3, 3), activation='relu'),
            keras.layers.MaxPooling2D(2, 2),
            keras.layers.Dropout(0.25),
            
            # Fourth Convolutional Block
            keras.layers.Conv2D(256, (3, 3), activation='relu'),
            keras.layers.BatchNormalization(),
            keras.layers.MaxPooling2D(2, 2),
            keras.layers.Dropout(0.25),
            
            # Fully Connected Layers
            keras.layers.Flatten(),
            keras.layers.Dense(512, activation='relu'),
            keras.layers.BatchNormalization(),
            keras.layers.Dropout(0.5),
            keras.layers.Dense(256, activation='relu'),
            keras.layers.Dropout(0.5),
            keras.layers.Dense(len(self.emotions), activation='softmax')
        ])
        
        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=0.001),
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def load_fer2013_dataset(self, csv_path):
        """
        Load FER2013 dataset for training
        Download from: https://www.kaggle.com/datasets/msambare/fer2013
        """
        import pandas as pd
        
        # Load CSV file
        df = pd.read_csv(csv_path)
        
        # Extract pixel data and labels
        pixels = df['pixels'].tolist()
        emotions = df['emotion'].tolist()
        
        # Convert pixel strings to numpy arrays
        X = []
        for pixel_string in pixels:
            pixel_values = [int(pixel) for pixel in pixel_string.split(' ')]
            pixel_array = np.array(pixel_values).reshape(48, 48, 1)
            X.append(pixel_array)
        
        X = np.array(X, dtype='float32') / 255.0
        
        # Convert emotions to categorical
        y = keras.utils.to_categorical(emotions, len(self.emotions))
        
        return X, y
    
    def train_model(self, X_train, y_train, X_val, y_val, epochs=50):
        """Train the emotion recognition model"""
        
        # Create model
        self.model = self.create_model()
        
        # Define callbacks
        callbacks = [
            keras.callbacks.EarlyStopping(
                monitor='val_accuracy',
                patience=10,
                restore_best_weights=True
            ),
            keras.callbacks.ReduceLROnPlateau(
                monitor='val_loss',
                factor=0.5,
                patience=5,
                min_lr=0.0001
            ),
            keras.callbacks.ModelCheckpoint(
                'models/best_emotion_model.h5',
                monitor='val_accuracy',
                save_best_only=True,
                verbose=1
            )
        ]
        
        # Data augmentation
        datagen = keras.preprocessing.image.ImageDataGenerator(
            rotation_range=10,
            width_shift_range=0.1,
            height_shift_range=0.1,
            horizontal_flip=True,
            zoom_range=0.1
        )
        
        # Train model
        history = self.model.fit(
            datagen.flow(X_train, y_train, batch_size=32),
            steps_per_epoch=len(X_train) // 32,
            epochs=epochs,
            validation_data=(X_val, y_val),
            callbacks=callbacks,
            verbose=1
        )
        
        return history
    
    def evaluate_model(self, X_test, y_test):
        """Evaluate model performance"""
        if self.model is None:
            print("Model not trained yet!")
            return
        
        # Evaluate on test set
        test_loss, test_accuracy = self.model.evaluate(X_test, y_test, verbose=0)
        print(f"Test Accuracy: {test_accuracy:.4f}")
        print(f"Test Loss: {test_loss:.4f}")
        
        # Generate classification report
        from sklearn.metrics import classification_report, confusion_matrix
        
        y_pred = self.model.predict(X_test)
        y_pred_classes = np.argmax(y_pred, axis=1)
        y_true_classes = np.argmax(y_test, axis=1)
        
        print("\nClassification Report:")
        print(classification_report(y_true_classes, y_pred_classes, 
                                  target_names=self.emotions))
        
        # Plot confusion matrix
        cm = confusion_matrix(y_true_classes, y_pred_classes)
        plt.figure(figsize=(10, 8))
        plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
        plt.title('Confusion Matrix')
        plt.colorbar()
        tick_marks = np.arange(len(self.emotions))
        plt.xticks(tick_marks, self.emotions, rotation=45)
        plt.yticks(tick_marks, self.emotions)
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()
        plt.savefig('confusion_matrix.png')
        plt.show()
    
    def save_model(self, filepath='models/emotion_model.h5'):
        """Save trained model"""
        if self.model is None:
            print("No model to save!")
            return
        
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        self.model.save(filepath)
        print(f"Model saved to {filepath}")

def main():
    """Main training function"""
    trainer = EmotionModelTrainer()
    
    # Load dataset (you need to download FER2013 dataset)
    print("Loading FER2013 dataset...")
    try:
        X, y = trainer.load_fer2013_dataset('data/fer2013.csv')
        print(f"Dataset loaded: {X.shape[0]} samples")
        
        # Split dataset
        X_train, X_temp, y_train, y_temp = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )
        X_val, X_test, y_val, y_test = train_test_split(
            X_temp, y_temp, test_size=0.5, random_state=42, stratify=y_temp
        )
        
        print(f"Training set: {X_train.shape[0]} samples")
        print(f"Validation set: {X_val.shape[0]} samples")
        print(f"Test set: {X_test.shape[0]} samples")
        
        # Train model
        print("Starting training...")
        history = trainer.train_model(X_train, y_train, X_val, y_val, epochs=50)
        
        # Evaluate model
        print("Evaluating model...")
        trainer.evaluate_model(X_test, y_test)
        
        # Save model
        trainer.save_model()
        
        # Plot training history
        plt.figure(figsize=(12, 4))
        
        plt.subplot(1, 2, 1)
        plt.plot(history.history['accuracy'], label='Training Accuracy')
        plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
        plt.title('Model Accuracy')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.legend()
        
        plt.subplot(1, 2, 2)
        plt.plot(history.history['loss'], label='Training Loss')
        plt.plot(history.history['val_loss'], label='Validation Loss')
        plt.title('Model Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        
        plt.tight_layout()
        plt.savefig('training_history.png')
        plt.show()
        
    except FileNotFoundError:
        print("FER2013 dataset not found. Please download it from Kaggle:")
        print("https://www.kaggle.com/datasets/msambare/fer2013")
        print("Place the fer2013.csv file in the 'data' directory")

if __name__ == "__main__":
    main()